$( document ).ready(function() {

  $('li').on('click', function() {
    $(this).toggleClass('selected');
  });


  // $( '.element' ).on({
  //   'click': function() {
  //     $(this).css('background-color','red');
  //   });

  // });
});
