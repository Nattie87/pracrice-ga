import React, { Component } from 'react';

class Footer extends Component {
  render() {
    return (
      <footer>
        Nattie
      </footer>

    );
  }
}

export default Footer;
